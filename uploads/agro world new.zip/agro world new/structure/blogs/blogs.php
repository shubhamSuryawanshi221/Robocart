<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Blogs</title>
</head>
<body>
    <header>
        <h1>Blogs</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="menu.php">Menu</a>
            <a href="cart.php">My Cart</a>
            <a href="about.php">About Us</a>
            <a href="login.php">Login</a>
            <a href="signup.php">Signup</a>
        </nav>
    </header>
    <main>
        <h2>Latest Articles</h2>
        <article>
            <h3>Benefits of Organic Farming</h3>
            <p>Organic farming is a sustainable way to grow crops without the use of synthetic fertilizers and pesticides.</p>
        </article>
        <article>
            <h3>Top 5 Vegetables to Grow in Your Garden</h3>
            <p>Learn about the best vegetables to grow in your home garden for a healthy diet.</p>
        </article>
    </main>
</body>
</html>