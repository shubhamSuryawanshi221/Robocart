<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO users (name, username, email, mobile, password) VALUES (?, ?, ?, ?, ?)");
    if ($stmt->execute([$name, $username, $email, $mobile, $password])) {
        $_SESSION['user_id'] = $pdo->lastInsertId();
        header('Location: profile.php');
        exit();
    } else {
        echo "Error: Could not create account.";
    }
}
?>